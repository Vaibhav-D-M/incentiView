const video = document.getElementById('ad-video');
let watchTime = 0;
let lastPlayTime = 0;

async function getWalletAddress() {
  if (typeof window !== 'undefined' && window.ethereum) {
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      return accounts[0];
    } catch (error) {
      console.error('Error fetching wallet address:', error);
      return null;
    }
  } else {
    console.error('MetaMask is not installed or window.ethereum is not available');
    return null;
  }
}

async function sendTokensForWatchTime(address, watchTime) {
  console.log(`Sending tokens for ${watchTime} seconds of watch time to address ${address}`);

  if (typeof window !== 'undefined' && window.ethereum) {
    const provider = new ethers.providers.Web3Provider(window.ethereum);
    const signer = provider.getSigner();
    const contractAddress = "0xa6Bfd157d5eA4C7A629C4cd50Aa8A9E6961cC001"; // Replace with your actual contract address
    const contract = new ethers.Contract(contractAddress, abi, signer);

    try {
      const tx = await contract.recordWatchTime(address, watchTime);
      await tx.wait();
      console.log("Tokens sent successfully");
    } catch (error) {
      console.error("Error sending tokens:", error);
    }
  } else {
    console.error('MetaMask is not installed or window.ethereum is not available');
  }
}

function calculateWatchTime() {
  const currentTime = video.currentTime;
  watchTime += currentTime - lastPlayTime;
  lastPlayTime = currentTime;
  console.log(`Watch time: ${watchTime} seconds`); // Log the watch time to the console

  getWalletAddress().then(address => {
    if (address) {
      sendTokensForWatchTime(address, watchTime);
    }
  });
}

video.addEventListener('play', () => {
  lastPlayTime = video.currentTime;
  if (watchTime === 0) {
    chrome.runtime.sendMessage({ publicId: 'your_public_id' });
  }
});

video.addEventListener('pause', calculateWatchTime);
video.addEventListener('ended', calculateWatchTime);

const abi = [
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "user",
        "type": "address"
      },
      {
        "internalType": "uint256",
        "name": "time",
        "type": "uint256"
      }
    ],
    "name": "recordWatchTime",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "inputs": [],
    "name": "withdrawRewards",
    "outputs": [],
    "stateMutability": "nonpayable",
    "type": "function"
  },
  {
    "stateMutability": "payable",
    "type": "receive"
  },
  {
    "inputs": [],
    "name": "rewardRate",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "name": "rewards",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  },
  {
    "inputs": [
      {
        "internalType": "address",
        "name": "",
        "type": "address"
      }
    ],
    "name": "watchTime",
    "outputs": [
      {
        "internalType": "uint256",
        "name": "",
        "type": "uint256"
      }
    ],
    "stateMutability": "view",
    "type": "function"
  }
];
