// Function to inject the iframe
function injectIframe() {
  const adSection = document.querySelector('#ad-section'); // Modify this selector based on the actual ad section selector on the website
  if (adSection) {
      const iframe = document.createElement('iframe');
      iframe.src = chrome.runtime.getURL('video.html'); // Assuming `video.html` contains your video player
      iframe.style.width = '100%';
      iframe.style.height = '100%';
      iframe.style.border = 'none';
      adSection.appendChild(iframe);
  }
}

// Run the function after the page is fully loaded
window.addEventListener('load', injectIframe);
